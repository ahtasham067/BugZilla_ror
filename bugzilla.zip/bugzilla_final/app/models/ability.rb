# frozen_string_literal: true

class Ability
  include CanCan::Ability

  def initialize(user)
    # Define abilities for the user here. For example:
    user ||= User.new # guest user (not logged in)
    if user.manager?
      can [:read, :create], Project
      can [:edit, :update, :destroy], Project, manager_id: user.id
      can :read, Bug
    elsif user.developer?
      can :read, Project do |project|
        user.projects.find_by_id(project.id).present?
      end
      can [:read, :edit, :update],Bug do |bug|
        user.projects.find_by_id(bug.project.id).present?
      end
    else
      can [:read, :create], Bug
      can [:edit, :update, :destroy], Bug, qa_id: user.id
      can :read, Project 
    end
    # The first argument to `can` is the action you are giving the user
    # permission to do.
    # If you pass :manage it will apply to every action. Other common actions
    # here are :read, :create, :update and :destroy.
    #
    # The second argument is the resource the user can perform the action on.
    # If you pass :all it will apply to every resource. Otherwise pass a Ruby
    # class of the resource.
    #
    # The third argument is an optional hash of conditions to further filter the
    # objects.
    # For example, here the user can only update published articles.
    #
    #   can :update, Article, published: true
    #
    # See the wiki for details:
    # https://github.com/CanCanCommunity/cancancan/blob/develop/docs/define_check_abilities.md
  end
end
